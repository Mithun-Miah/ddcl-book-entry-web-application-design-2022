btnSubmit.addEventListener('click', function() {
	const submit = document.getElementById('bookId').value;
	const bookTitle = document.getElementById('book-title').value;
	const bookSubTitle = document.getElementById('book-sub-title').value;
	const authoId = document.getElementById('autor-id').value;
	//console.log(submit, bookTitle, bookSubTitle, authoId);
	
	// This is for result input
	const result = document.getElementById('result');

	result.innerText = (submit + " " + bookTitle + " " + bookSubTitle + " " + authoId);
	
	result.style.color = 'white';
	result.style.fontSize = '20px';
})
let btnClear = document.querySelector('#btnClear');
let inputs = document.querySelectorAll('input');

btnClear.addEventListener('click', function() {
	inputs.forEach(input => input.value = '');
})

// Close Button Action
let logOut = document.querySelector('.btnClose');

logOut.addEventListener('click', function () {
	window.open('login.html', '_self');
})